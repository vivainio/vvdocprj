QmlReddit

Copyright (C) 2011 Ville M. Vainio <vivainio@gmail.com>

Licensed under GPLv2 or later. Storage.js, Storage.qml licensed
under LGPL (see file headers).
